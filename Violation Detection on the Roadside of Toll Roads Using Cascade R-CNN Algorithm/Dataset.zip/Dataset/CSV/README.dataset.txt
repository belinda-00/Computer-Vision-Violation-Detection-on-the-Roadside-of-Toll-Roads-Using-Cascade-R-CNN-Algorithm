# mask > 2023-01-30 9:59pm
https://universe.roboflow.com/alfian-imran-x6azu/mask-c0fan

Provided by a Roboflow user
License: CC BY 4.0

